#pragma once

enum class EntityName
{
	Player = 0,
	Zombie
};