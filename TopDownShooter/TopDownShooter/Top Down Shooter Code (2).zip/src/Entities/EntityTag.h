#pragma once

enum class EntityTag
{
	Player = 0,
	Enemy
};