#pragma once

enum class KeyCode
{
	A = 0,
	D = 3,
	S = 18,
	W = 22,
	Total
};