#pragma once

#include <SFML\Window.hpp>

enum class InputEvent
{
	KeyA = 0,
	KeyD = 3,
	KeyS = 18,
	KeyW = 22,
	
	Total
};