#pragma once

enum class Direction
{
	Left = 0,
	Right,
	Up,
	Down,
	None
};