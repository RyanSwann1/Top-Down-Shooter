#pragma once

enum class GlobalMessage
{
	CloseWindow = 0
};