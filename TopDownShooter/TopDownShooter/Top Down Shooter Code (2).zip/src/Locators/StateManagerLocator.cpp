#include <Locators\StateManagerLocator.h>
StateManager* StateManagerLocator::m_stateManager = nullptr;