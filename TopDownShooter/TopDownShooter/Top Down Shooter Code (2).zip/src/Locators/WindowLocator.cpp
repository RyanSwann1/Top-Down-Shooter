#include <Locators\WindowLocator.h>
Window* WindowLocator::m_window = nullptr;