#include <Locators\GlobalMessengerLocator.h>
GlobalMessenger* GlobalMessengerLocator::m_globalMessenger = nullptr;