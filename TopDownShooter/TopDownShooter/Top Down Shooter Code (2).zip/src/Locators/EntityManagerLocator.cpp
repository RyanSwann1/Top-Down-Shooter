#include <Locators\EntityManagerLocator.h>
EntityManager* EntityManagerLocator::m_entityManager = nullptr;