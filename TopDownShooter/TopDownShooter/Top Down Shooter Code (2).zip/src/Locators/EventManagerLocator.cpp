#include <Locators\EventManagerLocator.h>
EventManager* EventManagerLocator::m_eventManager = nullptr;