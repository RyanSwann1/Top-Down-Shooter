#include <Locators\StringToEnumConverterLocator.h>
StringToEnumConverter* StringToEnumConverterLocator::m_stringToEnumConverter = nullptr;

