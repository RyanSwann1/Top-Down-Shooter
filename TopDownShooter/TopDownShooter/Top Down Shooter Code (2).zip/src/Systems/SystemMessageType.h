#pragma once

enum class SystemMessageType
{
	Base = 0,
	Position
};