#pragma once

enum class SystemType
{
	Drawable = 0,
	Movable,
	PlayerController,
	Total,
	Global
};