#pragma once

enum class SystemEvent
{
	MoveLeft = 0,
	MoveRight,
	MoveUp,
	MoveDown
};