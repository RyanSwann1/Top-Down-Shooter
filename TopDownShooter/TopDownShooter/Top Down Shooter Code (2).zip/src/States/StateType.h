#pragma once

enum class StateType
{
	Game = 0,
	MainMenu
};