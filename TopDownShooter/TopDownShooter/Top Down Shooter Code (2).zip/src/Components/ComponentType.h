#pragma once

enum class ComponentType
{
	Position = 0,
	Drawable,
	Movable,
	Rotation,
	Total
};